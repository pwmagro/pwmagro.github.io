<?php

namespace Grav\Plugin;

use Grav\Common\Plugin;

/**
 * Class DevToolsPlugin
 * @package Grav\Plugin
 */
class DevToolsPlugin extends Plugin
{
}
