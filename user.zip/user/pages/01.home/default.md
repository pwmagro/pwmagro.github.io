---
title: home
body_classes: title-center title-h1h2
---

# hi there. <br> i'm peter magro.

i'm an electrical & computer engineering student at the University of Colorado Boulder, but i'm also an artist, musician, synthesizer enthusiast, rhythm game player, and take-things-apart-and-forget-how-to-reassemble-them-er.

this is where you can find my musings, as well as details on ongoing projects. my main focus right now is on [ergodash](/ergodash), my custom controller for Muse Dash, osu!mania, and similar rhythm games.