---
title: music
taxonomy:
    tag: [hi, howdy]
---

# i make music too.

there's not too much to say about this one. i don't stick to any one genre, but there's a bit of a trend towards dubstep. give it a listen if you like.

<iframe style="border: 0; width: 70%; height: 307px; margin: auto; display: block;" src="https://bandcamp.com/EmbeddedPlayer/album=3268288770/size=large/bgcol=333333/linkcol=fe7eaf/artwork=small/transparent=true/" seamless><a href="https://wdym.bandcamp.com/album/peak">Peak by WDYM</a></iframe>

## if you like what you hear

streaming services do not pay artists terribly well. by buying my music on [Bandcamp](https://wdym.bandcamp.com), you're supporting me directly, as well as getting the lossless download to listen to my music wherever, whenever, forever.

however, you can still listen to my music in any number of places, including [Spotify](), [Apple Music](), [YouTube Music](), [Soundcloud](), and more. no matter where you go, support is always appreciated.

---

! note to self: this aint an actual blog post